/** Automatically generated file. DO NOT MODIFY */
package br.com.fabianoacsx;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}